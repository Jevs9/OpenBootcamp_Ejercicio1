public class Main {
    public static void main(String[] args) {
        suma(10, 20, 50);
    }
    public static void  suma(int a, int b, int c){
        int resultado;
        resultado = a + b + c;
        System.out.println(resultado);
    }
}